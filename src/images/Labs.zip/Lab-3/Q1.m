%Clearing Terminal & Workspace
clc
clear 

%Constants
Fs = 1000;
Tb = 1;

%Generating Rectangular Pulse
% tp = -1:1/Fs:1;
% r = rect(tp,Fs+200,Tb);

%Generating Raised Cosine Pulse
tp = -Tb/2:1/Fs:Tb/2;
Bt = Fs/2;
roll = 0.5;
Rb = 2*Bt/(1+roll);
r = rcp(tp+Tb/2,0.6,Rb);

%Don't Touch [Pre-Processing]
y = round(r);
z = r(r ~= 0);
m = length(z);
tend = (0.5*m)/Fs;
p = r(tp >= -Tb/2 & tp <= tend);

subplot(3,1,1)
plot(tp,r);

%Random Bits
noOfBits = 10;
bits = mod(1:noOfBits,2);
disp(bits)

%Line Coding
t = 0:1/Fs:noOfBits*Tb;
x = zeros(size(t));
x(mod(t,Tb) == 0 & t ~= noOfBits*Tb) = bits;
s = cconv(x,p,length(x));

subplot(3,1,2)
plot(t,s)

%Decoding
decodedBits = round(s(mod(t,Tb) == 0 & t ~= noOfBits*Tb));
disp(decodedBits)


%Rect Pulse Generator
function y = rect(tp,Fs,Tb)
    n = length(tp);
    f = -Fs/2:Fs/n:Fs/2-Fs/n;
    Y = Tb*sinc(f*Tb);
    y = abs(ifftshift(ifft(Y)))*Fs;
end

%Raised Cosine Pulse
function y = rcp(t,roll,Rb)
    y = cos(pi*roll*Rb*t).*sinc(Rb*t)./(1-4*(roll*roll)*(Rb*Rb)*(t.*t));
end