% Parameters
Fs = 1000;        % Sampling frequency
T = 1 / Fs;       % Sampling period
N = 1024;         % Number of samples
f0 = 50;          % Center frequency of the pulse
T_pulse = 0.2;    % Width of the pulse in seconds

% Time vector
t = (0:N-1) * T;

% Frequency vector
f = linspace(-Fs/2, Fs/2, N);

% Design the frequency spectrum (non-ideal rectangular pulse)
A = 1; % Amplitude of the pulse
frequency_spectrum = A * sinc(f * T_pulse) .* (1 - 0.5 * cos(2*pi*(f - f0) * T_pulse));

% Generate the time-domain signal via inverse Fourier transform
time_domain_signal = ifftshift(ifft(ifftshift(frequency_spectrum)));

% Plotting
subplot(2, 1, 1);
plot(f, abs(frequency_spectrum));
title('Magnitude of Frequency Spectrum');
xlabel('Frequency (Hz)');
ylabel('Magnitude');

subplot(2, 1, 2);
plot(t, real(time_domain_signal));
title('Time-Domain Signal');
xlabel('Time (s)');
ylabel('Amplitude');

sgtitle('Non-Ideal Rectangular Pulse in Frequency Domain');