% Sampling and Reconstruction Example for signal cos(s*pi*fm*t)
clc;
clear

% Define the signal parameters
fm = 200;         % Frequency of the cosine signal (Hz)
t =  0:1/1e4:100/fm;   % Time vector from 0 to 1 seconds

% Define the original signal
x = cos(2*pi*fm*t);

% Plot the original signal
subplot(2, 2, 1);
plot(t, x);
title('Original Signal');
xlabel('Time (s)');
ylabel('Amplitude');
xlim([0 15e-3])

% Case 1: Over-sampling
fs_oversampled = 4000;                 % More than Nyquist frequency
t_oversampled = 0:1/fs_oversampled:100/fm; % Time vector for over-sampled signal
x_oversampled = cos(2*pi*fm*t_oversampled);  % Sampled signal

% Plot the over-sampled signal
subplot(2, 2, 2);
stem(t_oversampled, x_oversampled);
hold on;
plot(t,x,'r');
hold off;
title('Over-sampled Signal');
xlabel('Time (s)');
ylabel('Amplitude');
xlim([0 5e-3])

% Case 2: Under-sampling
fs_undersampled = 250;                 % Less than Nyquist frequency
t_undersampled = 0:1/fs_undersampled:100/fm; % Time vector for under-sampled signal
x_undersampled = cos(2*pi*fm*t_undersampled);  % Sampled signal

% Plot the under-sampled signal
subplot(2, 2, 3);
stem(t_undersampled, x_undersampled);

hold on;
plot(t,x,'r');
hold off;

title('Under-sampled Signal');
xlabel('Time (s)');
ylabel('Amplitude');
xlim([0 5e-2])

% Case 3: Critical sampling
fs_critical = 400;                 % Less than Nyquist frequency
t_critical = 0:1/fs_critical:100/fm; % Time vector for under-sampled signal
x_critical = cos(2*pi*fm*t_critical);     % Sampled signal

% Plot the critical sampled signal
subplot(2, 2, 4);
stem(t_critical, x_critical);
hold on;
plot(t, x, 'r');
hold off;
title('Critical Sampled Signal');
xlabel('Time (s)');
ylabel('Amplitude');
xlim([0 5e-2])

figure;
subplot(3,1,1)
x_critical_reconstructed = lowpass(x_critical,fm,fs_critical);
plot(t_critical,x_critical_reconstructed);
xlim([0 5e-2])


subplot(3,1,2)
x_under_reconstructed = lowpass(x_undersampled,fm,fs_undersampled);
plot(t_undersampled,x_under_reconstructed);
xlim([0 5e-2])

subplot(3,1,3)
x_over_reconstructed = lowpass(x_oversampled,fm,fs_oversampled);
plot(t_oversampled,x_over_reconstructed);
xlim([0 5e-2])

function y = lowpass(x,fm,fs)
    n = length(x); 

    f = (-n/2:n/2-1)*2*(fs+fm)/n; %Low Pass Filter Range
    X = fftshift(fft(x));   %Fourier Transform
       
    %Lowpass Filter in Fourier Domain
    Y = zeros(size(X));
    Y(f >= -fm | f<= fm) = X(f > -fm | f<= fm);
    
    y = real(ifft(ifftshift(Y)));
end