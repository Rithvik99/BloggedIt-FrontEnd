%% Sampling and Reconstruction Example for signal cos(2*pi*fm*t)
% --- Explanation ---
% This code demonstrates the process of sampling and reconstruction.
% The message/information signal is is a cosine signal.
% Then, the signal is sampled using a sampling frequency.
% The reconstruction process is performed using the sinc function for interpolation.
% The last subplot compares the reconstructed signal with the original signal for visual analysis.
% Overall, this example illustrates the effect of sampling rate on reconstruction of original signal.

clc; clear all;

%% Define msg signal parameters
msgFreq = 200;         
msgPeriod = 1/msgFreq;
% Define the time vector for 5 cycles (5 periods) of the signal
% Define the original cos (.) signal for 5 cycles

%% Generate Sampled the signal


%% Reconstruction
rSignal = zeros(size(msgDuration));
for i = 1:length(sInstants)
    % Use the sinc function for interpolation
    rSignal = rSignal + sSignal(i) * sinc((msgDuration - sInstants(i))*sFreq);
end

%% Plot the signals
subplot(2, 2, 1); % original signal


subplot(2, 2, 2); % sampled signal and its envalop in the same plot


subplot(2, 2, 3); % reconstructed signal


subplot(2, 2, 4); % Plot the reconstructed signal and the original signal for comparison


%% Sinc function for Interpolation (Reconstruction using Low-pass Filter)
function y = sinc(x)
    y = sin(pi*x)./(pi*x);
    y(x == 0) = 1;
end

