% Sampling and Reconstruction Example for signal cos(2*pi*fm*t)

% Clear the workspace and command window
clc;
clear all;

% Define the signal parameters
frequency = 1000;          % Frequency of the cosine signal (Hz)

% Calculate the period T of the signal
T = 1 / frequency;

% Define the time vector for 5 cycles (5 periods) of the signal
time = 0:0.0001:5*T;

% Define the original signal for 5 cycles
original_signal = cos(2 * pi * frequency * time);

% Plot the original signal
subplot(2, 2, 1);
plot(time, original_signal);
title('Original Signal');
xlabel('Time (s)');
ylabel('Amplitude');

% Sampling the signal
sampling_frequency = 800;          % New sampling frequency
time_sampled = 0:(1/sampling_frequency):5*T;

sampled_signal = cos(2 * pi * frequency * time_sampled);

% Plot the sampled signal
subplot(2, 2, 2);
stem(time_sampled, sampled_signal, 'b'); % Use 'stem' for discrete samples (blue stems)
hold on;
plot(time_sampled, sampled_signal, 'r'); % Also, plot the continuous signal (red line)
hold off;
title('Sampled Signal');
xlabel('Time (s)');
ylabel('Amplitude');

% Reconstruction for over-sampling
reconstructed_signal = zeros(size(time));
for i = 1:length(time_sampled)
    % Use the sinc function for interpolation
    reconstructed_signal = reconstructed_signal + sampled_signal(i) * sinc((time - time_sampled(i)) * sampling_frequency);
end

% Plot the reconstructed signal
subplot(2, 2, 3);
plot(time, reconstructed_signal);
title('Reconstructed Signal');
xlabel('Time (s)');
ylabel('Amplitude');

% Plot the reconstructed signal and the original signal for comparison
subplot(2, 2, 4);
plot(time, reconstructed_signal, 'b'); % Plot reconstructed signal in blue
hold on;
plot(time, original_signal, 'r');     % Plot original signal in red
hold off;
title('Reconstructed Signal vs Original Signal');
xlabel('Time (s)');
ylabel('Amplitude');
legend('Reconstructed Signal', 'Original Signal');

% Reconstruction using Ideal Low-pass Filter
% Define the sinc function
function y = sinc(x)
    y = sin(pi*x)./(pi*x);
    y(x == 0) = 1;
end

% --- Explanation ---
% This code demonstrates the process of sampling and reconstruction of a cosine signal.
% The original continuous signal is generated using the cosine function and plotted.
% Then, the signal is sampled at a new sampling frequency, and both the discrete samples and the continuous signal are plotted.
% The reconstruction process involves using the sinc function for interpolation, and the reconstructed signal is plotted.
% The last subplot compares the reconstructed signal with the original signal for visual analysis.
% Overall, this example illustrates how sampling and reconstruction impact the representation of a continuous signal.