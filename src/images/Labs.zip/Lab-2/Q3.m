% PCM Implementation

% Parameters
Fs = 500;           % Sampling frequency (Hz)
duration = 1;       % Duration of signal (seconds)
bitsPerSample = 3;  % Number of bits per sample

% Generate a message signal (sine wave)
t = 0:1/Fs:duration-1/Fs;
f_message = 10;     % Frequency of the message signal (Hz)
messageSignal = sin(2*pi*f_message*t);

% Normalize the message signal to the range [-1, 1]
messageSignal = messageSignal / max(abs(messageSignal));

% Quantization levels
quantLevels = 2^bitsPerSample;

% Encode the message signal using PCM
quantizedSignal = round((messageSignal + 1) * (quantLevels - 1) / 2);

% Decode the quantized signal
decodedSignal = (2 * quantizedSignal) / (quantLevels - 1) - 1;

% Plot the original message signal
subplot(4,1,1);
plot(t, messageSignal);
title('Original Message Signal');
xlabel('Time (s)');
ylabel('Amplitude');

% Plot the quantized signal
subplot(4,1,2);
stem(t, quantizedSignal, 'r');
title('Quantized Signal (PCM)');
xlabel('Time (s)');
ylabel('Quantized Value');

% Plot the decoded message signal
subplot(4,1,3);
plot(t, decodedSignal);
title('Decoded Message Signal');
xlabel('Time (s)');
ylabel('Amplitude');

% Filter and plot the filtered message signal
subplot(4,1,4)
filtered_signal = lowpass(decodedSignal, 30, Fs);
plot(t, filtered_signal);
hold on
plot(t,messageSignal,'-r')
hold off
title('Filtered vs Original Message Signal');
legend('Filtered Signal','Original Signal')
xlabel('Time (s)');
ylabel('Amplitude');