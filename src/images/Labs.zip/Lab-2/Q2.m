%Refreshing Workspace & Terminal
clc
clear

% Constants
fm = 200; % Frequency of the message signal in Hz
Fs = 10000; % Sampling frequency in Hz
duration = 0.01; % Signal duration in seconds
t = 0:1/Fs:duration;

% Generate the message signal
message_signal = cos(2*pi*fm*t);

subplot(3,1,1)
plot(t,message_signal)
grid on
grid minor
title('Message Signal')
xlabel('Time')
ylabel('Amplitude')

%Quantization : Lookup dsearchn
message_range = max(message_signal) - min(message_signal);
L = 8; %Number of Levels
D = message_range/L; %Step Size
n = ceil(log2(L)); %Number of Bits 

gap = message_range - (L-1)*D; 
level_0 = min(message_signal) + gap/2; %First Level
levels = level_0 + (0:L-1)*D; %All the Levels
symbols = dsearchn(levels',message_signal')-1; %Levels Numbers of All samples
quantised_signal = levels(symbols+1); % +1 because symbols are 0-indexed

subplot(3,1,2)
plot(t,quantised_signal)
grid on
grid minor
title('Qunatised Signal')
xlabel('Time')
ylabel('Amplitude')

%Encoding 
bitstream = int2bit(symbols,n);

% Decoding
received_symbols = bit2int(bitstream,n);
received_signal = levels(received_symbols+1);% +1 because symbols are 0-indexed

%Signal Reconstruction : Passing Through Lowpass Filter of passband fm
recovered_signal = lowpass(received_signal,fm,Fs); 

subplot(3,1,3)
plot(t,recovered_signal)
grid on
grid minor
title('Recovered Signal')
xlabel('Time')
ylabel('Amplitude')