% Constants
fm = 200; % Frequency of the message signal in Hz
Fs = 10000; % Sampling frequency in Hz
duration = 0.01; % Signal duration in seconds
t = 0:1/Fs:duration;

% Generate the message signal
message_signal = cos(2*pi*fm*t);

% Sampling parameters
Fs_new = 5000; % New sampling frequency in Hz

% Perform sampling
t_sampled = 0:1/Fs_new:duration;
sampled_signal = cos(2*pi*fm*t_sampled);

% Number of quantization levels
num_levels = 8; % You can choose any desired number of levels (e.g., 8, 16, etc.)

% Quantization step size
quantization_step = (max(sampled_signal) - min(sampled_signal)) / (num_levels - 1);

% Perform quantization
quantized_signal = round(sampled_signal / quantization_step) * quantization_step;

% Plot the original message signal
figure;
subplot(3, 1, 1);
plot(t, message_signal);
title('Original Message Signal');
xlabel('Time (s)');
ylabel('Amplitude');

% Plot the sampled signal
subplot(3, 1, 2);
plot(t_sampled, sampled_signal);
hold on
stem(t_sampled, sampled_signal);
hold off
title('Sampled Signal');
xlabel('Time (s)');
ylabel('Amplitude');

% Plot the quantized signal
subplot(3, 1, 3);
plot(t_sampled, quantized_signal);
title('Quantized Signal');
xlabel('Time (s)');
ylabel('Amplitude');

% Bit conversion
num_bits = log2(num_levels); % Number of bits needed to represent num_levels
binary_signal = de2bi((quantized_signal - min(quantized_signal)) / quantization_step, num_bits, 'left-msb');

% Display the binary representation
disp("Binary representation of quantized signal:");
disp(binary_signal);

% Convert the binary representation back to quantized levels
quantized_levels = bi2de(binary_signal, 'left-msb') * quantization_step + min(quantized_signal);

% Reconstruct the original signal from the quantized levels
reconstructed_signal = interp1(t_sampled, quantized_levels, t, 'previous');

% Plot the reconstructed signal
figure;
subplot(2,1,1)
plot(t, reconstructed_signal);
hold on;
plot(t, message_signal, '-r');
hold off;
legend('Reconstructed Signal', 'Original Message Signal');
title('Reconstructed Signal vs Original Message Signal');
xlabel('Time (s)');
ylabel('Amplitude');

% Filtering out ripples
cutoff_freq = 200; % Cutoff frequency of the low-pass filter in Hz
order = 1; % First-order filter
% Pass the reconstructed signal through the low-pass filter
filtered_signal = lowpass(reconstructed_signal, cutoff_freq, Fs);

% Plot the filtered signal
subplot(2,1,2)
plot(t, filtered_signal);
hold on;
plot(t, message_signal, '-r');
hold off;
legend('Filtered Signal', 'Original Message Signal');
title('Filtered Signal vs Original Message Signal');
xlabel('Time (s)');
ylabel('Amplitude');