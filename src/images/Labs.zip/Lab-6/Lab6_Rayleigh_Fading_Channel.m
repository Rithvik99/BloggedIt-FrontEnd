%Refershing Terminal & Workspace
clc
clear

%Globals
N = 1e6;

%Distributions : Raleigh Fading Channel
h = (randn(1,N) + 1j*randn(1,N))/sqrt(2);
a = abs(h);
phi = angle(h);


subplot(2,1,1)
pdfa = hist(a,0:0.05:4);
bar(0:0.05:4,pdfa/N/0.05)

%Graph Specifics
title('PDF of Amplitude')
grid 
xlabel('a')
ylabel('f A(a)')

subplot(2,1,2)
pdfp = hist(phi,-pi:0.05:pi);
bar(-pi:0.05:pi,pdfp/N/0.05)

%Graph Specifics
title('PDF of Phase')
grid
xlabel('\theta')
ylabel('f_\Theta(\theta)')


