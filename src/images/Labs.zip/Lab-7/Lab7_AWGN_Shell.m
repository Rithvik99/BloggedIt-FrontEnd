clear all;
close all;
clc

% Parameters
numBits = 10000;  % Number of bits to transmit
snrRange = 0:2:20;  % Range of SNR values to simulate (in dB)
numSNRs = length(snrRange);
numBlocks = 10;  % Number of blocks to simulate

% Initialize variables to store BER results for 4-QAM and 16-QAM
bitErrors4QAM = zeros(numSNRs, 1);
bitErrors16QAM = zeros(numSNRs, 1);

for snrIdx = 1:numSNRs
    snr = snrRange(snrIdx);
    noiseVar = 1;  % Set the noise variance to 1
    
    % Calculate the signal energy based on the desired SNR
    signalEnergy = ;
    
    % Initialize bit error counts for this SNR
    totalBitErrors4QAM = 0;
    totalBitErrors16QAM = 0;
    
    for block = 1:numBlocks
        % Generate random bits (0 or 1)
        txBits = ;
        
        % Map bits to 4-QAM symbols with the adjusted signal energy
        txSymbols4QAM = ;
        txSymbols4QAM = ;
        
        % Add Gaussian noise using 'awgn' function (same noise as 16-QAM)
        rxSymbols4QAM = ;
        
        % Demodulation (Minimum distance) for 4-QAM
        rxBits4QAM = ;
        rxBits4QAM = ;
        
        % Calculate bit errors for 4-QAM
        bitErrorsBlock4QAM = ;
        
        % Accumulate bit errors for 4-QAM
        totalBitErrors4QAM = ;
        
        % Modulate and demodulate using inbuilt functions for 16-QAM
        % Functions given
        txBits = ;
        txSymbols16QAM = qammod(); 
        rxSymbols16QAM = awgn();
        rxBits16QAM = qamdemod();
        
        % Calculate bit errors for 16-QAM
        bitErrorsBlock16QAM = sum();
        
        % Accumulate bit errors for 16-QAM
        totalBitErrors16QAM = ;
    end
    
    % Calculate BER for both 4-QAM and 16-QAM for this SNR
    bitErrorRate4QAM = ;
    bitErrorRate16QAM = ;
    bitErrors4QAM(snrIdx) = bitErrorRate4QAM;
    bitErrors16QAM(snrIdx) = bitErrorRate16QAM;
end

% Plot BER vs SNR for both 4-QAM and 16-QAM
figure;
semilogy(snrRange, bitErrors4QAM, '-o', 'DisplayName', '4-QAM');
hold on;
semilogy(snrRange, bitErrors16QAM, '-o', 'DisplayName', '16-QAM');
grid on;
xlabel('SNR (dB)');
ylabel('Bit Error Rate (BER)');
title('BER vs SNR for 4-QAM and 16-QAM Modulation');
legend('Location', 'best');


figure;

% Plot transmitted 4-QAM symbols
subplot(2, 2, 1);
scatter(real(txSymbols4QAM), imag(txSymbols4QAM), 'g.');
title('Transmitted 4-QAM Symbols');
xlabel('I');
ylabel('Q');

% Plot received 4-QAM symbols
subplot(2, 2, 2);
scatter(real(rxSymbols4QAM), imag(rxSymbols4QAM), 'b.');
title('Received 4-QAM Symbols');
xlabel('I');
ylabel('Q');

% Plot transmitted 16-QAM symbols
subplot(2, 2, 3);
scatter(real(txSymbols16QAM), imag(txSymbols16QAM), 'm.');
title('Transmitted 16-QAM Symbols');
xlabel('I');
ylabel('Q');

% Plot received 16-QAM symbols
subplot(2, 2, 4);
scatter(real(rxSymbols16QAM), imag(rxSymbols16QAM), 'r.');
title('Received 16-QAM Symbols');
xlabel('I');
ylabel('Q');