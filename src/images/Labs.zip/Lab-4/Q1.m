%Refresing Workspace
clc
clear

%Global Variables
N = 1e6;
bitstream = randi([0 1],[1,N]);
N0 = 1;

%Loop Iterables
SNR = 0:0.1:10;
Eb = N0*(10.^(SNR/10))/2;

bpskBER = zeros(size(SNR));
bfskBER = zeros(size(SNR));

%Iterating Over SNR
for i = 1:length(SNR)
    %BPSK Scheme
    bpsk  = BPSK(bitstream,Eb(i));
    rbpsk = channel(bpsk,N0);
    obpsk = dBPSK(rbpsk);

    %BFSK Scheme
    bfsk  = BFSK(bitstream,Eb(i));
    rbfsk = channel(bfsk,N0);
    obfsk = dBFSK(rbfsk);

    %BERs
    bpskBER(i) = (sum(obpsk ~= bitstream))/N;
    bfskBER(i) = (sum(obfsk ~= bitstream))/N;
end

%BPSK : calculated
semilogy(SNR,qfunc(sqrt(2*Eb/N0)),'LineWidth',1.5)

%BFSK : calculated
hold on
semilogy(SNR,qfunc(sqrt(Eb/N0)),'LineWidth',1.5)
hold off

%BPSK Plot
hold on
scatter(SNR,bpskBER)
hold off

%BFSK Plot
hold on
scatter(SNR,bfskBER)
hold off

%Graph Specifics
grid on 
grid minor

legend('Expected BER_B_P_S_K','Expected BER_B_F_S_K', ...
                'Experimental BER_B_P_S_K','Experimental BER_B_F_S_K')
xlabel('E_b/N_o (in db)')
ylabel('BER')


%BPSK 0 -> (-1,0) | 1 -> (1,0)
function y = BPSK(bitstream,Eb)
    y = zeros(size(bitstream));
    y(bitstream == 0) = -1+0j;
    y(bitstream == 1) = +1+0j;
    y = sqrt(Eb)*y;
end

%BFSK 0 -> (1,0) | 1 -> (0,1)
function y = BFSK(bitstream,Eb)
    y = zeros(size(bitstream));
    y(bitstream == 0) = 1+0j;
    y(bitstream == 1) = 0+1j;
    y = sqrt(Eb)*y;
end

%Noisy Channel
function y = channel(signal,N0)
    Nc = sqrt(N0/2)*randn(size(signal));
    Ns = sqrt(N0/2)*randn(size(signal));
    y = signal + Nc + Ns*1j;
end

%Demodulator BPSK  : ML rule
function y = dBPSK(signal)
     ds1 = abs(signal-(-1+0j));
     ds0 = abs(signal-(+1+0j));
     y   = zeros(size(signal));
     y(ds0 < ds1) = 1;
end

%Demodulator BFSK  : ML rule
function y = dBFSK(signal)
     ds1 = abs(signal-(1+0j));
     ds0 = abs(signal-(0+1j));
     y   = zeros(size(signal));
     y(ds0 < ds1) = 1;
end