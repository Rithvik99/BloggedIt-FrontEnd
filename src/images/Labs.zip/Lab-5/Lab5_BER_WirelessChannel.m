%Refershing Terminal & Workspace
clc
clear

blockLength = 1e3;
nBlocks = 2e4;
SNRdb = 0:4:32;
SNR = 10.^(SNRdb/10);

No = 1;
BER = zeros(size(SNRdb));
BER1 = zeros(size(SNRdb));

for blk = 1:nBlocks
    h = (randn + 1j*randn);
    Bits = randi([0,1],1,blockLength);
    Sym = 2*Bits - 1;
    noise = sqrt(No/2)*(randn(1,blockLength)+1j*randn(1,blockLength));

    for K = 1: length(SNRdb)
        TxSym = sqrt(SNR(K))*Sym;
        RxSym = h*TxSym + noise;
        EqSym = RxSym/h;
        Decbits = (real(EqSym) > 0);
        BER(K) = BER(K) + sum(Decbits ~= Bits);
    end

    for K = 1: length(SNRdb)
        TxSym = sqrt(SNR(K))*Sym;
        RxSym = TxSym + noise;
        EqSym = RxSym;
        Decbits = (real(EqSym) > 0);
        BER1(K) = BER1(K) + sum(Decbits ~= Bits);
    end
end

BER = BER/blockLength/nBlocks;
BER1 = BER1/blockLength/nBlocks;

semilogy(SNRdb,BER,'r','LineWidth',3.0,'MarkerFaceColor', ...
        'g','MarkerSize',9.0)
grid on
legend('BER')
xlabel('SNR(dB)')
ylabel('BER')

hold on
semilogy(SNRdb,BER1,'b','LineWidth',3.0,'MarkerFaceColor', ...
        'g','MarkerSize',9.0)
hold off 

legend('Wireless Channel','Wired Channel')
